package sustinereExamene.classes.main;

import sustinereExamene.classes.classes.Student;
import sustinereExamene.classes.classes.SustinereExamen;

public class MainSustinere {
    Student student1 = new Student(123,"Pop Diana","popdiana@stud.ase.ro",3);
    Student student2 = new Student(124,"Popescu Denisa","popescuden@stud.ase.ro",3);

    SustinereExamen examenPoo = new SustinereExamen("POO");
    SustinereExamen examenCts = new SustinereExamen("CTS");

    examenPoo.inregistrareStudent(student1);
    examenPoo.inregistrareStudent(student2);
    examenPoo.inregistrareStudent(student1);
}
