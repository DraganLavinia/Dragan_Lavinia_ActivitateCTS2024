package sustinereExamene.classes.classes;

import sustinereExamene.classes.classes.Student;

import java.util.HashMap;
import java.util.Map;

public class SustinereExamen {
    private String numeStudent;

    Map<Integer, Student> listaStudenti = new HashMap<>();

    public SustinereExamen(String numeStudent) {
        this.numeStudent = numeStudent;
    }

    public String getNumeStudent() {
        return numeStudent;
    }

    public Map<Integer, Student> getListaStudenti() {
        return listaStudenti;
    }

    public void inregistrareStudent(Student student){
        if(listaStudenti.containsKey(student.getId())){
            System.out.println("Studentul " + student.getNume() + " a sustinut deja examenul!");
        }
        else{
            listaStudenti.put(student.getId(),student);
            System.out.println("Studentul " + student.getNume() + " sustine deja examenul!");
        }
    }

}
