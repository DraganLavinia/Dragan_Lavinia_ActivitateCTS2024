package BazadeDate.classes.main;

import BazadeDate.classes.classes.ConexiuneBazaDeDate;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        ConexiuneBazaDeDate conexiune1 = ConexiuneBazaDeDate.getInstance("Baza1", 20, "link1");
        ConexiuneBazaDeDate conexiune2 = ConexiuneBazaDeDate.getInstance("Baza2", 30, "link2");

        conexiune1.setNumeBaza("NumeBazaNoua");
        conexiune2.setNumeBaza("NumeBazaNoua2");

        System.out.println(conexiune1);
        System.out.println(conexiune2);


    }
}