package builder.classes.builder_v3;

public interface IBuilderV3 {
    Pacient build();
}
