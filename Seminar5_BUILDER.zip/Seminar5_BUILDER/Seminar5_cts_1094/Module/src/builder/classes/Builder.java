package builder.classes;

public interface Builder {
    //public Builder(boolean patRabatabil, boolean papuci, boolean micDeJunInclus, boolean halatInterior) {
    //super(patRabatabil, papuci, micDeJunInclus, halatInterior);
    // }

    Pacient build();

}
