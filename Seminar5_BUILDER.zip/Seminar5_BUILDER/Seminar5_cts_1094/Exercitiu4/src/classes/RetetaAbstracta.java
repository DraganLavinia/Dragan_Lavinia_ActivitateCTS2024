package classes;

public interface RetetaAbstracta {
    RetetaAbstracta clone();
}
