package SimpleFactory.main;

import SimpleFactory.classes.PersonalSpital;
import SimpleFactory.classes.fabrica.FactorySimple;
import SimpleFactory.classes.fabrica.TipPersonal;

public class Main {
    public static void main(String[] args) {
        FactorySimple fabricaPersonal = new FactorySimple();
        try{
            PersonalSpital medic = fabricaPersonal.createPersonal(TipPersonal.MEDIC,"Popescu",5000);
            PersonalSpital asistent = fabricaPersonal.createPersonal(TipPersonal.ASISTENT,"Topescu",6500);
            PersonalSpital brancardier = fabricaPersonal.createPersonal(TipPersonal.BRANCARDIER,"Moldovan",5000);
            medic.afisareDetalii();
            asistent.afisareDetalii();
            brancardier.afisareDetalii();
        }catch (Exception ex){
            throw  new RuntimeException(ex);
        }
    }
}