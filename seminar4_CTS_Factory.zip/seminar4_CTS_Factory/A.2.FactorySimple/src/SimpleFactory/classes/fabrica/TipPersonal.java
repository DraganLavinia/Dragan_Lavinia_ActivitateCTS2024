package SimpleFactory.classes.fabrica;

public enum TipPersonal {
    MEDIC,
    ASISTENT,
    BRANCARDIER,
    INFIRMIER
}
