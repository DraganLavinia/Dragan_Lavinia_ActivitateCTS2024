package main;

import classes.Medic;
import classes.PersonalSpital;
import classes.factory.FabricaAsistent;
import classes.factory.FabricaBrancardier;
import classes.factory.FabricaMedic;
import classes.factory.FabricaPersonal;

public class Main {
    public static void prelucarePersonal(FabricaPersonal fabrica,String nume, int salariu) {
        PersonalSpital personal = fabrica.createPersonal(nume,salariu);

        personal.afisareDetalii();
    }
    public static void main(String[] args) {
        //FabricaPersonal fabricaAsistent = new FabricaAsistent();
        //FabricaPersonal fabricaMedic = new FabricaMedic();
        // FabricaPersonal fabricaBrancardier = new FabricaBrancardier();
        //PersonalSpital medic = fabricaMedic.createPersonal("Popescu",10000);
        //PersonalSpital asistent = fabricaAsistent.createPersonal("Georgescu",6000);
        //PersonalSpital brancardier = fabricaBrancardier.createPersonal("Gheorgheu",4000);

        //medic.afisareDetalii();
        //daca adaug un infirmier add clasa si fabrica si prelucrarea va sti deja cu ce sa lucreze


        prelucarePersonal(new FabricaBrancardier(),"Popescu", 5000);
        }
    }
}